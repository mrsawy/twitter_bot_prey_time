
console.log(process.env.test)